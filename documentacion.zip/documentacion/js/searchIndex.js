Search.appendIndex(
    [
                {
            "fqsen": "\\calcularAreaTriangulo\u0028\u0029",
            "name": "calcularAreaTriangulo",
            "summary": "Calcula\u0020el\u0020\u00E1rea\u0020de\u0020un\u0020tri\u00E1ngulo.",
            "url": "namespaces/default.html#function_calcularAreaTriangulo"
        },                {
            "fqsen": "\\calcularPerimetroTriangulo\u0028\u0029",
            "name": "calcularPerimetroTriangulo",
            "summary": "Calcula\u0020el\u0020per\u00EDmetro\u0020de\u0020un\u0020tri\u00E1ngulo.",
            "url": "namespaces/default.html#function_calcularPerimetroTriangulo"
        },                {
            "fqsen": "\\UserManager",
            "name": "UserManager",
            "summary": "Clase\u0020para\u0020gestionar\u0020usuarios.",
            "url": "classes/UserManager.html"
        },                {
            "fqsen": "\\UserManager\u003A\u003AcreateUser\u0028\u0029",
            "name": "createUser",
            "summary": "Crea\u0020un\u0020nuevo\u0020usuario.",
            "url": "classes/UserManager.html#method_createUser"
        },                {
            "fqsen": "\\UserManager\u003A\u003AupdateUser\u0028\u0029",
            "name": "updateUser",
            "summary": "Actualiza\u0020los\u0020datos\u0020de\u0020un\u0020usuario\u0020existente.",
            "url": "classes/UserManager.html#method_updateUser"
        },                {
            "fqsen": "\\",
            "name": "\\",
            "summary": "",
            "url": "namespaces/default.html"
        }            ]
);
