<?php
/**
 * Calcula el área de un triángulo.
 *
 * Este script calcula el área de un triángulo utilizando la fórmula
 * del área (base * altura / 2).
 *
 * @package Scripts
 * @author Hind Samiri
 * @version 2.0
 * @link http://localhost/hinsam/distancia23/
 
 * @since 2023-05-15
 * @license MIT
 */

/**
 * Calcula el área de un triángulo.
 *
 * Esta función recibe la base y la altura de un triángulo y devuelve
 * el área calculada.
 *
 * @param float $base La base del triángulo.
 * @param float $altura La altura del triángulo.
 * @return float El área del triángulo.
 * @version 2.0
 
 
 */
function calcularAreaTriangulo($base, $altura) {
    return ($base * $altura) / 2;
}

/**
 * Calcula el perímetro de un triángulo.
 *
 * Esta función recibe los lados de un triángulo y devuelve el perímetro
 * calculado.
 *
 * @param float $lado1 El primer lado del triángulo.
 * @param float $lado2 El segundo lado del triángulo.
 * @param float $lado3 El tercer lado del triángulo.
 * @return float El perímetro del triángulo.
 * @version 1.0
 */
function calcularPerimetroTriangulo($lado1, $lado2, $lado3) {
    return $lado1 + $lado2 + $lado3;
}

// Resto del código del script...

